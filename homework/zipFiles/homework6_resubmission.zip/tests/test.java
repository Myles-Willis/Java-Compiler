public class IfTest {
   public static void main(String args[]) {
	  int a;
	  int b;

	  if(a < b) {
		  a = 5;
	  }

	  b = 3;
   }
}
