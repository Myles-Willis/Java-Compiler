// public class hello {
//    public static void main(String argv[]) {
//       int x;
//       x = 1;
//       x = x + 2;
//       if (x > 3) {
//          System.out.println("hello, jzero!");
//          x = x - 1;
//       }
//    }
// }

// public class hello {
//
// 	public static void write(int x) {
// 		x = 1;
// 	}
//
// 	public static void main(String argv[]) {
// 	   int i;
// 	   i = 5;
// 	   i = i * i + 1;
// 	   write(i);
// 	}
// }

// public class basic {
// public static int x ;
// public static void main(String []argv) {
//    x = 5;
//    x = x * x;
// }
// }

// public class typeck {
// public static int fib(int i) {
//    return 11;
// }
//
// public static void main(String [] argv) {
//    int i;
//    i = 0 + 1;
//    return 0;
// }
// }

public class jstuff {

public static void main(String [] argv) {
  String m;
  m = "h";
  m = m + "3";
  m = m + "l";
  m = m + "l";
  m = m + "o";
  m = m + "0";
  System.out.println("" + m);
}
}
