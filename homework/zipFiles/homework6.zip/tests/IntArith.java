public class hello {
    double a;
    float i;
	char j;
    public static void main(String argv[]) {
        i = a * 1 + 3;
        // a = 15;
        // a++;
        // a = i - 14 / 5 % 4;
        // i = a + a;
		// i = a++;
		// a = i--;
		// a = 1 + (2 + 3 * (4 - 5));

		boolean x = true;
    }
}
