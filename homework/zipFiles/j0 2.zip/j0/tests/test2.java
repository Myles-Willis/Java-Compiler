public class test2 { int f() {
   int thread_local = 5;
   return thread_local;
} }
// test2.java output [expect syntax error on line 5]
