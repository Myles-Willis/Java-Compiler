public class hello {

	public static int z;
	public static int s = 3;

	public static int test(int a, char b, String c) {
		// a = 1;
		// b = 'x';
		// c = 3;
		s = 2;
	}

   public static void main(String argv[]) {
	   int x;
	   x = 10;

	   int a = 18;
	   int v = 9;
	   boolean b = ("hello" == "goodbye");
	   boolean c = (123 != 456);
	   boolean d = (b && c);
	   boolean e = ( (b && c || true) || c);

	   String g = "Hello";
	   char i = 'i';
	   int h = 1;
	   int j = 1;
	   int k = 1;
	   int l = 1;

	   // char q, w, e, t;

	   a = 4 - 56 * 'c';
	   i = test(h, i, g);
   }




}
