public class test2 { public static int f() {
   float thread_local = 5.55;
   int a = 10;
   return thread_local;
} }
// test2.java output [expect syntax error on line 5]
