public class HelloWorld {
	int a = 5;
	public static void main() {
	  double d;
	  int x, y;
	  int T;
	  String s;
	  C c;
	  int b = 3 * 6;
	  char k = 'z';
	  c = null;

	  while (x < 10) {
	     if (x == 9.55) {
	     break;
	     } else if (x <= 5) {
	     break;
	     } else if (x >= 15) {
	     break;
	     } else {
	     x = 1;
	     }
	     }
	  for (x=0; x < 3; x=1) { x++; }
	  for (x=3; x > 0; x=1) { x--; }
	  // L[1] = 5 * 5 / x % 5;
	  // L[1] = x;
	  if (x<=y && y>=0 || y!=-1) { System.out.println("hello\n"); }
	  return;
	}
}
