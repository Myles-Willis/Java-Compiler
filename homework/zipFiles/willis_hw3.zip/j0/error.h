#ifndef ERROR_H
#define ERROR_H

#include "defs.h"
int yyerror(char *s);
void print_error(char *errorMsg);

#endif
