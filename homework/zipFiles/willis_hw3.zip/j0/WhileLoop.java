public class hello {
    int a;
    int i;
   public static void main(String argv[]) {
      while(a && i || !a){
          System.out.println("juicy\t");
      }
   }
}
