public class test1 {
public static void main() {
   System.out.println("Hello\tworld\n");
} }
// test1.java output [expect a syntax tree]
