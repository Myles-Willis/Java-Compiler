public class hello {
    double a;
    String i;
	char j;
    public static void main(String argv[]) {
        i = a * 4 + 2;
        a = 15;
        a++;
        a = i - 14 / 5 % 4;
        i = a + a;
		i = a++;
		a = i--;
		a = 1 + (2 + 3 * (4 - 5));

		boolean x = 10;
    }
}
