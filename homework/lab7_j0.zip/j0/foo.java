public class foo {
   public static int foo(int x, String y) {
      return x;
     }

   public static int main()
  {
   int z;
   z = foo(5, "funf");
   return 0;
   }
}
